
const bundles = {
  mtn: {
    "1GB - 7GHS": "https://paystack.com/buy/mtn-1gb-bjxmqg"
  },
  at: {
    "2GB - 10GHS": "https://paystack.com/buy/at-2gb-stapoc"
  },
  telecel: {
    "10GB - 50GHS": "https://paystack.com/buy/telecel-10gb-ucwlmh"
  }
};

const networkSelect = document.getElementById("network");
const bundleSelect = document.getElementById("bundle");

networkSelect.addEventListener("change", () => {
  const selectedNetwork = networkSelect.value;
  bundleSelect.innerHTML = '<option value="">Select a bundle</option>';
  if (bundles[selectedNetwork]) {
    Object.keys(bundles[selectedNetwork]).forEach(bundle => {
      const opt = document.createElement("option");
      opt.value = bundle;
      opt.textContent = bundle;
      bundleSelect.appendChild(opt);
    });
  }
});

document.getElementById("bundleForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("fullName").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const network = networkSelect.value;
  const bundle = bundleSelect.value;
  const notes = document.getElementById("notes").value;
  const payURL = bundles[network][bundle];
  alert("Redirecting to payment page...");
  window.location.href = payURL;
  const orderID = "ORD" + Date.now();
  const message = `Order ID: ${orderID}%0AName: ${name}%0AEmail: ${email}%0APhone: ${phone}%0ANetwork: ${network.toUpperCase()}%0ABundle: ${bundle}%0ANotes: ${notes}`;
  const whatsappURL = `https://wa.me/233598699581?text=${encodeURIComponent(message)}`;
  setTimeout(() => {
    window.open(whatsappURL, "_blank");
  }, 3000);
});

function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}

const testimonials = document.querySelectorAll(".testimonial");
let index = 0;
setInterval(() => {
  testimonials.forEach(t => t.classList.remove("active"));
  index = (index + 1) % testimonials.length;
  testimonials[index].classList.add("active");
}, 5000);

const sections = document.querySelectorAll(".container, .testimonials");
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("show");
  });
}, { threshold: 0.1 });

sections.forEach(section => observer.observe(section));

if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
  document.body.classList.add('dark-mode');
}
